# Intent Economy Recommendations

## offer-safe-001 / Transparent SupportAI Co. / match
- No material issue detected.
- Recommendation: Offer can be presented as a consented option, not as default coercion.

## offer-review-002 / Growth Intent Cloud / review
- Issue: Requested data outside consent: financial, precise_location
- Issue: Sensitive data classes requested: financial, precise_location
- Recommendation: Remove data classes outside the consent grant or request explicit new consent.
- Recommendation: Route only with user-facing disclosure, revised terms and human review.

## offer-block-003 / BlackBox Intent Broker / block
- Issue: Manipulation or dark-pattern pressure terms detected: last chance, limited time, act now, scarcity, fear, guaranteed
- Issue: Prohibited or high-risk use terms detected: covert profiling, hidden tracking, sell to data broker, indefinite retention
- Issue: Requested data outside consent: financial, health, precise_location
- Issue: Sensitive data classes requested: financial, health, precise_location
- Issue: Indefinite retention detected.
- Issue: Free offer requests broad data; possible unfair value exchange.
- Issue: Weak evidence for promised value.
- Recommendation: Remove data classes outside the consent grant or request explicit new consent.
- Recommendation: Add case studies, measurable outcomes, independent references or audit reports.
- Recommendation: Do not route this offer to the user until prohibited use, excessive data and manipulation risks are removed.
