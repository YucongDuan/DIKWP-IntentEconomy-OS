# Integration Guide

DIKWP IntentEconomy OS can integrate with:

- DIKWP IntentGuard OS: pre-execution policy gate.
- DIKWP MemoryLedger OS: long-term purpose continuity.
- DIKWP ProofLedger OS: claim-to-evidence support.
- DIKWP AgentTrace OS: runtime trace and replay.
- DIKWP TrustPassport OS: official registry and badge layer.

Recommended flow:

1. User creates IntentContract.
2. MemoryLedger stores long-term purpose under consent.
3. IntentEconomy creates DemandBrief.
4. Vendors or agents submit offers.
5. IntentGuard blocks unsafe offers.
6. ProofLedger checks promised claims.
7. AgentTrace records accepted workflows.
