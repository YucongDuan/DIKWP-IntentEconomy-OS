# Code of Conduct

Be constructive, evidence-oriented and respectful. Do not use this project to target, manipulate or deceive users.
