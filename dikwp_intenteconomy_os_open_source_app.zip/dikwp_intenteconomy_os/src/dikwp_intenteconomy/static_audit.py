import ast
import json
from pathlib import Path
from typing import Dict, List

FORBIDDEN_IMPORTS = {"socket", "requests", "urllib", "httpx", "subprocess", "paramiko", "ftplib"}
FORBIDDEN_CALLS = {"eval", "exec", "compile", "__import__"}


def audit_source_tree(src_dir: str) -> Dict[str, object]:
    findings: List[Dict[str, object]] = []
    for path in Path(src_dir).rglob("*.py"):
        text = path.read_text(encoding="utf-8")
        tree = ast.parse(text)
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root = alias.name.split(".")[0]
                    if root in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(path), "line": node.lineno, "type": "forbidden_import", "value": alias.name})
            elif isinstance(node, ast.ImportFrom):
                root = (node.module or "").split(".")[0]
                if root in FORBIDDEN_IMPORTS:
                    findings.append({"file": str(path), "line": node.lineno, "type": "forbidden_import", "value": node.module})
            elif isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name) and node.func.id in FORBIDDEN_CALLS:
                    findings.append({"file": str(path), "line": node.lineno, "type": "forbidden_call", "value": node.func.id})
    return {
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic execution, hidden tracking, credential capture, or host mutation helpers in the offline core.",
    }


def write_audit(src_dir: str, out_path: str) -> Dict[str, object]:
    result = audit_source_tree(src_dir)
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result
