# Security Policy

Report security issues privately to the project maintainers. The offline core should not include network calls, hidden telemetry, dynamic execution or host mutation helpers.
