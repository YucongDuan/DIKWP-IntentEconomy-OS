# DIKWP Intent Steward Certification Program

Proposed levels:

- IS-L1: Intent Contract User
- IS-L2: Intent Governance Analyst
- IS-L3: Intent Market Integrator
- IS-L4: DIKWP Intent Steward
- IS-L5: Certified Intent Economy Auditor

Certification should test:

- DIKWP P-layer understanding
- consent and revocation design
- manipulation risk detection
- demand brief design
- high-impact domain boundary
- evidence ledger and residual handling
