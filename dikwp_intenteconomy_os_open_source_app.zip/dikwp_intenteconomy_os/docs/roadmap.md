# Roadmap

## v0.2

- Add multilingual intent contract templates.
- Add more manipulation pattern detectors.
- Add vendor self-attestation form.

## v0.3

- Add TrustPassport integration.
- Add ProofLedger citation hooks.
- Add MemoryLedger integration for long-term purpose continuity.

## v1.0

- Launch official DIKWP Intent Passport registry.
- Publish certification program.
- Add enterprise policy packs.
