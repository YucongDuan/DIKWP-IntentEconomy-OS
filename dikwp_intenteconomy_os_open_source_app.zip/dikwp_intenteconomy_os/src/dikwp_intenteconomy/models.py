from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class IntentContract:
    intent_id: str
    subject_id: str
    goal: str
    value: str
    constraints: List[str]
    time_window: str
    feedback_plan: str
    allowed_data_classes: List[str]
    forbidden_uses: List[str]
    expiration: str
    revocation_endpoint: str


@dataclass
class Offer:
    offer_id: str
    vendor: str
    proposal: str
    requested_data: List[str]
    promised_value: str
    retention: str
    personalization_methods: List[str]
    persuasion_methods: List[str]
    price_or_consideration: str
    evidence: List[str] = field(default_factory=list)


@dataclass
class ConsentGrant:
    grant_id: str
    subject_id: str
    allowed_uses: List[str]
    allowed_data_classes: List[str]
    retention: str
    expiration: str
    revocable: bool
    human_review_required: bool


@dataclass
class DIKWPRecord:
    D: Dict[str, Any]
    I: Dict[str, Any]
    K: Dict[str, Any]
    W: Dict[str, Any]
    P: Dict[str, Any]
    R: Dict[str, Any]


@dataclass
class OfferEvaluation:
    offer_id: str
    vendor: str
    alignment_score: float
    consent_score: float
    data_minimization_score: float
    manipulation_risk: float
    value_fairness_score: float
    evidence_score: float
    sovereignty_score: float
    decision: str
    issues: List[str]
    recommendations: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class IntentEconomyReport:
    system: str
    version: str
    intent_id: str
    decision_summary: Dict[str, int]
    mean_sovereignty_score: float
    max_manipulation_risk: float
    evaluations: List[OfferEvaluation]
    dikwp_intent_record: DIKWPRecord
    consent_ledger: Dict[str, Any]
    demand_brief: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["evaluations"] = [e.to_dict() for e in self.evaluations]
        return data
