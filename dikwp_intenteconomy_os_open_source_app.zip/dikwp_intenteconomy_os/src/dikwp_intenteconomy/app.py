try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None

from .evaluator import analyze


def main() -> None:
    if st is None:
        raise RuntimeError("Streamlit is not installed. Install with pip install -e .[app]")
    st.title("DIKWP IntentEconomy OS")
    st.write("Offline intent sovereignty and ethical intent exchange prototype.")
    input_path = st.text_input("Input JSON", "examples/sample_intent_marketplace.json")
    out_dir = st.text_input("Output directory", "outputs/demo")
    if st.button("Analyze"):
        report = analyze(input_path, out_dir)
        st.json(report.to_dict())

if __name__ == "__main__":
    main()
