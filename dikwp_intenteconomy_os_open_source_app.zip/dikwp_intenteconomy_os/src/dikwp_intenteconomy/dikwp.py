from typing import Any, Dict
from .models import DIKWPRecord, IntentContract


def build_intent_record(intent: IntentContract, source: Dict[str, Any]) -> DIKWPRecord:
    return DIKWPRecord(
        D={
            "subject_id": intent.subject_id,
            "declared_goal": intent.goal,
            "declared_constraints": intent.constraints,
            "source_type": source.get("source_type", "user_declared"),
        },
        I={
            "relationships": [
                "goal-value-constraint-time-feedback structure",
                "allowed_data_classes vs requested_data matching",
                "user-owned intent vs platform-inferred intent boundary",
            ],
            "time_window": intent.time_window,
            "expiration": intent.expiration,
        },
        K={
            "model": "DIKWP IntentContract: goal, value, constraints, time, feedback",
            "governance_rule": "Offers must align with declared intent, consent and data minimization.",
            "risk_model": "Manipulation pressure and excessive data requests reduce sovereignty score.",
        },
        W={
            "values": [intent.value],
            "forbidden_uses": intent.forbidden_uses,
            "privacy_boundary": "No hidden profiling or indefinite retention without explicit consent.",
        },
        P={
            "goal": intent.goal,
            "value": intent.value,
            "constraints": intent.constraints,
            "time_window": intent.time_window,
            "feedback_plan": intent.feedback_plan,
        },
        R={
            "reliability": "Supported / user-declared / local prototype",
            "residual": "Declared intent can change; offer matching is heuristic and requires human review for consequential decisions.",
            "kill_conditions": [
                "offer requests forbidden use",
                "offer requires sensitive data outside consent",
                "offer uses urgency, fear, scarcity or hidden tracking to reshape intent",
            ],
        },
    )
