from dikwp_intenteconomy.evaluator import analyze
from dikwp_intenteconomy.static_audit import audit_source_tree


def test_demo_decisions(tmp_path):
    report = analyze("examples/sample_intent_marketplace.json", str(tmp_path), "configs/default_policy.json")
    assert report.decision_summary["match"] == 1
    assert report.decision_summary["block"] == 1
    assert report.max_manipulation_risk >= 0.65


def test_output_files(tmp_path):
    analyze("examples/sample_intent_marketplace.json", str(tmp_path), "configs/default_policy.json")
    assert (tmp_path / "intent_economy_report.json").exists()
    assert (tmp_path / "demand_brief.json").exists()
    assert (tmp_path / "offer_scorecard.csv").exists()


def test_static_audit_passes():
    result = audit_source_tree("src")
    assert result["pass"] is True
