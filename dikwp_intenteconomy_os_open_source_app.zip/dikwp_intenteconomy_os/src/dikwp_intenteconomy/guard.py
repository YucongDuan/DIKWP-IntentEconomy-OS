from typing import List, Tuple
from .text_utils import norm_text

MANIPULATION_TERMS = [
    "last chance", "limited time", "act now", "only today", "scarcity",
    "fear", "shame", "guilt", "pressure", "exclusive secret", "guaranteed",
    "only correct", "100%", "no risk", "instant decision", "dark pattern",
]

PROHIBITED_USE_TERMS = [
    "political microtargeting", "covert profiling", "hidden tracking", "surveillance",
    "sell to data broker", "indefinite retention", "share with affiliates without consent",
    "manipulate", "deceive", "credential", "password", "api key", "secret key",
]

SENSITIVE_DATA_CLASSES = [
    "health", "mental_health", "financial", "minor", "precise_location",
    "biometric", "legal", "religion", "political", "sexual_orientation",
]


def scan_offer_text(payload: object) -> Tuple[float, List[str]]:
    text = norm_text(payload)
    issues: List[str] = []
    hits = [t for t in MANIPULATION_TERMS if t in text]
    if hits:
        issues.append("Manipulation or dark-pattern pressure terms detected: " + ", ".join(hits[:6]))
    bad = [t for t in PROHIBITED_USE_TERMS if t in text]
    if bad:
        issues.append("Prohibited or high-risk use terms detected: " + ", ".join(bad[:6]))
    risk = min(1.0, 0.15 * len(hits) + 0.35 * len(bad))
    return risk, issues
