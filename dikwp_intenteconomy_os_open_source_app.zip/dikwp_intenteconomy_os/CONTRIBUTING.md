# Contributing

Contributions should preserve the non-manipulative, consent-first positioning of this project.

Do not contribute code for covert profiling, hidden tracking, dark-pattern generation, surveillance, credential capture, political manipulation or bypassing user consent.
