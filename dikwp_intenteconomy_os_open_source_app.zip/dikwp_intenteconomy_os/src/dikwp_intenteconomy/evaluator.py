import csv
import json
from pathlib import Path
from statistics import mean
from typing import Any, Dict, List

from .dikwp import build_intent_record
from .guard import SENSITIVE_DATA_CLASSES, scan_offer_text
from .models import ConsentGrant, IntentContract, Offer, OfferEvaluation, IntentEconomyReport
from .text_utils import clamp, norm_text


def load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def parse_contract(data: Dict[str, Any]) -> IntentContract:
    return IntentContract(**data["intent_contract"])


def parse_consent(data: Dict[str, Any]) -> ConsentGrant:
    return ConsentGrant(**data["consent_grant"])


def parse_offers(data: Dict[str, Any]) -> List[Offer]:
    return [Offer(**item) for item in data.get("offers", [])]


def overlap_score(a: List[str], b: List[str]) -> float:
    if not a:
        return 0.0
    aset = {x.lower() for x in a}
    bset = {x.lower() for x in b}
    return len(aset & bset) / max(1, len(bset)) if bset else 1.0


def evidence_score(evidence: List[str]) -> float:
    if not evidence:
        return 0.0
    score = 0.0
    for item in evidence:
        text = item.lower()
        if "case" in text or "study" in text or "metric" in text or "report" in text or "audit" in text:
            score += 0.25
        else:
            score += 0.12
    return clamp(score)


def evaluate_offer(intent: IntentContract, consent: ConsentGrant, offer: Offer, policy: Dict[str, Any]) -> OfferEvaluation:
    issues: List[str] = []
    recommendations: List[str] = []
    combined = {
        "proposal": offer.proposal,
        "methods": offer.personalization_methods + offer.persuasion_methods,
        "retention": offer.retention,
        "requested_data": offer.requested_data,
    }
    manipulation_risk, guard_issues = scan_offer_text(combined)
    issues.extend(guard_issues)

    goal_terms = set(norm_text(intent.goal).split()) | set(norm_text(intent.value).split())
    offer_terms = set(norm_text(offer.proposal + " " + offer.promised_value).split())
    alignment_score = clamp(len(goal_terms & offer_terms) / max(3, min(len(goal_terms), 12)) + 0.2)

    consent_data_score = overlap_score(consent.allowed_data_classes, offer.requested_data)
    forbidden_requested = [d for d in offer.requested_data if d.lower() not in {x.lower() for x in consent.allowed_data_classes}]
    if forbidden_requested:
        issues.append("Requested data outside consent: " + ", ".join(forbidden_requested))
        recommendations.append("Remove data classes outside the consent grant or request explicit new consent.")
    sensitive_requested = [d for d in offer.requested_data if d.lower() in SENSITIVE_DATA_CLASSES]
    data_minimization_score = clamp(1.0 - (0.08 * len(offer.requested_data)) - (0.12 * len(sensitive_requested)))
    if sensitive_requested:
        issues.append("Sensitive data classes requested: " + ", ".join(sensitive_requested))

    retention_text = offer.retention.lower()
    if "indefinite" in retention_text or "forever" in retention_text:
        issues.append("Indefinite retention detected.")
        manipulation_risk = clamp(manipulation_risk + 0.25)
        data_minimization_score = clamp(data_minimization_score - 0.3)

    value_fairness_score = 0.7
    if "free" in offer.price_or_consideration.lower() and len(offer.requested_data) > 4:
        value_fairness_score -= 0.25
        issues.append("Free offer requests broad data; possible unfair value exchange.")
    if "revenue share" in offer.price_or_consideration.lower() or "discount" in offer.price_or_consideration.lower():
        value_fairness_score += 0.1

    e_score = evidence_score(offer.evidence)
    if e_score < policy.get("min_evidence_score", 0.2):
        issues.append("Weak evidence for promised value.")
        recommendations.append("Add case studies, measurable outcomes, independent references or audit reports.")

    consent_score = consent_data_score if consent.revocable else consent_data_score * 0.7
    if not consent.revocable:
        issues.append("Consent grant is not revocable.")

    sovereignty_score = clamp(
        0.24 * alignment_score
        + 0.20 * consent_score
        + 0.18 * data_minimization_score
        + 0.14 * value_fairness_score
        + 0.14 * e_score
        + 0.08 * (1 - manipulation_risk)
    )

    if manipulation_risk >= policy.get("block_manipulation_risk", 0.65) or any("Prohibited" in i for i in issues):
        decision = "block"
    elif sovereignty_score < policy.get("review_threshold", 0.55) or issues:
        decision = "review"
    else:
        decision = "match"

    if decision == "block":
        recommendations.append("Do not route this offer to the user until prohibited use, excessive data and manipulation risks are removed.")
    elif decision == "review":
        recommendations.append("Route only with user-facing disclosure, revised terms and human review.")
    else:
        recommendations.append("Offer can be presented as a consented option, not as default coercion.")

    return OfferEvaluation(
        offer_id=offer.offer_id,
        vendor=offer.vendor,
        alignment_score=round(alignment_score, 4),
        consent_score=round(consent_score, 4),
        data_minimization_score=round(data_minimization_score, 4),
        manipulation_risk=round(manipulation_risk, 4),
        value_fairness_score=round(clamp(value_fairness_score), 4),
        evidence_score=round(e_score, 4),
        sovereignty_score=round(sovereignty_score, 4),
        decision=decision,
        issues=issues,
        recommendations=recommendations,
    )


def build_demand_brief(intent: IntentContract, consent: ConsentGrant) -> Dict[str, Any]:
    return {
        "intent_id": intent.intent_id,
        "public_goal": intent.goal,
        "value_anchor": intent.value,
        "non_negotiable_constraints": intent.constraints,
        "time_window": intent.time_window,
        "allowed_data_classes": consent.allowed_data_classes,
        "forbidden_uses": intent.forbidden_uses,
        "revocation_endpoint": consent.expiration if not consent.revocable else intent.revocation_endpoint,
        "sharing_note": "Share this brief with vendors or agents instead of exposing raw personal history.",
    }


def analyze(input_path: str, out_dir: str, policy_path: str = "configs/default_policy.json") -> IntentEconomyReport:
    payload = load_json(input_path)
    policy = load_json(policy_path) if Path(policy_path).exists() else {}
    intent = parse_contract(payload)
    consent = parse_consent(payload)
    offers = parse_offers(payload)
    evaluations = [evaluate_offer(intent, consent, offer, policy) for offer in offers]
    decision_summary: Dict[str, int] = {"match": 0, "review": 0, "block": 0}
    for ev in evaluations:
        decision_summary[ev.decision] = decision_summary.get(ev.decision, 0) + 1
    record = build_intent_record(intent, payload)
    report = IntentEconomyReport(
        system="DIKWP IntentEconomy OS",
        version="0.1.0",
        intent_id=intent.intent_id,
        decision_summary=decision_summary,
        mean_sovereignty_score=round(mean([ev.sovereignty_score for ev in evaluations]) if evaluations else 0.0, 4),
        max_manipulation_risk=round(max([ev.manipulation_risk for ev in evaluations]) if evaluations else 0.0, 4),
        evaluations=evaluations,
        dikwp_intent_record=record,
        consent_ledger={"grant": consent.__dict__, "status": "active" if consent.revocable else "restricted"},
        demand_brief=build_demand_brief(intent, consent),
    )
    write_outputs(report, out_dir)
    return report


def write_outputs(report: IntentEconomyReport, out_dir: str) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    data = report.to_dict()
    (out / "intent_economy_report.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "intent_contract.json").write_text(json.dumps(data["dikwp_intent_record"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "consent_ledger.json").write_text(json.dumps(data["consent_ledger"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "demand_brief.json").write_text(json.dumps(data["demand_brief"], ensure_ascii=False, indent=2), encoding="utf-8")
    with open(out / "offer_scorecard.csv", "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["offer_id", "vendor", "decision", "sovereignty_score", "manipulation_risk", "alignment_score", "consent_score", "evidence_score"])
        writer.writeheader()
        for ev in report.evaluations:
            writer.writerow({
                "offer_id": ev.offer_id,
                "vendor": ev.vendor,
                "decision": ev.decision,
                "sovereignty_score": ev.sovereignty_score,
                "manipulation_risk": ev.manipulation_risk,
                "alignment_score": ev.alignment_score,
                "consent_score": ev.consent_score,
                "evidence_score": ev.evidence_score,
            })
    recommendations = ["# Intent Economy Recommendations", ""]
    for ev in report.evaluations:
        recommendations.append(f"## {ev.offer_id} / {ev.vendor} / {ev.decision}")
        recommendations.extend([f"- Issue: {i}" for i in ev.issues] or ["- No material issue detected."])
        recommendations.extend([f"- Recommendation: {r}" for r in ev.recommendations])
        recommendations.append("")
    (out / "recommendations.md").write_text("\n".join(recommendations), encoding="utf-8")
