import argparse
import json
from .evaluator import analyze
from .static_audit import write_audit


def main() -> None:
    parser = argparse.ArgumentParser(prog="intenteconomy")
    sub = parser.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("analyze")
    p.add_argument("input")
    p.add_argument("--policy", default="configs/default_policy.json")
    p.add_argument("--out", default="outputs/demo")
    a = sub.add_parser("static-audit")
    a.add_argument("src")
    a.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    args = parser.parse_args()
    if args.cmd == "analyze":
        report = analyze(args.input, args.out, args.policy)
        print(json.dumps({"intent_id": report.intent_id, "decision_summary": report.decision_summary, "mean_sovereignty_score": report.mean_sovereignty_score}, ensure_ascii=False))
    elif args.cmd == "static-audit":
        result = write_audit(args.src, args.out)
        print(json.dumps(result, ensure_ascii=False))

if __name__ == "__main__":
    main()
