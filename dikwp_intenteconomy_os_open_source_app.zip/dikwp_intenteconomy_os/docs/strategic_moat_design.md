# Strategic Moat Design

The open-source core should spread the DIKWP intent economy vocabulary, but the official value layer should remain difficult to copy.

## Open-source layer

- IntentContract schema.
- ConsentLedger schema.
- DemandBrief generator.
- Offer evaluation heuristics.
- Demo and CLI.

## Controlled official layer

- Official DIKWP Intent Passport issuer.
- Official registry for verified intent-market tools.
- Industry-specific intent contract templates.
- Certification and partner programs.
- Enterprise deployment playbooks.
- Legal and compliance review packages.

The open-source project creates adoption; the official registry, certification and templates create durable benefit for Yucong Duan / DIKWP.
