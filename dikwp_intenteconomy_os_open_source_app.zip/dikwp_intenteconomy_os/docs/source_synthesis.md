# Source Synthesis

This project is informed by DIKWP, the intention economy, AI agent governance, privacy and consent concerns, information overload theory and purpose-layer design.

Core ideas:

- Information abundance does not automatically generate wisdom.
- Intention is not a simple desire; it is a structured relation of goal, value, constraints, time and feedback.
- AI assistants can shift from answering user queries to influencing user decisions.
- DIKWP adds a Purpose layer that can make user intent explicit, auditable and revocable.
