from typing import Iterable


def norm_text(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        return " ".join(norm_text(v) for v in value)
    if isinstance(value, dict):
        return " ".join(norm_text(v) for v in value.values())
    return str(value).lower()


def contains_any(text: str, needles: Iterable[str]) -> bool:
    text = text.lower()
    return any(n.lower() in text for n in needles)


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def safe_slug(text: str) -> str:
    out = []
    for ch in text.lower():
        if ch.isalnum():
            out.append(ch)
        elif ch in "-_ ":
            out.append("-")
    return "".join(out).strip("-") or "item"
