# DIKWP Model Mapping

## D / Data

Declared goal, constraints, requested data, vendor offers, evidence snippets and consent terms.

## I / Information

Relations between goal, offer, data class, consent scope, retention and promised value.

## K / Knowledge

Known governance principles: consent, data minimization, revocation, manipulation risk, evidence support and fair value exchange.

## W / Wisdom

User sovereignty, privacy, autonomy, non-manipulation, proportionality and human review.

## P / Purpose

The IntentContract: goal, value, constraints, time window and feedback plan.

## R / Reliability

Heuristic local scoring, user-declared reliability, offer evidence strength, residuals and kill conditions.
