# GitHub Release Draft

## DIKWP IntentEconomy OS v0.1.0

This release introduces an offline-first toolkit for user-owned Intent Contracts, consent ledgers, demand briefs and ethical intent offer evaluation.

Highlights:

- DIKWP C=(D,I,K,W,P,R) registration for user intent.
- Consent ledger and revocation-aware matching.
- Manipulation risk detection.
- Offer sovereignty scorecard.
- Demand brief generator.
- Static boundary audit.

Boundary: This is not a dark-pattern, surveillance or hidden profiling toolkit.
