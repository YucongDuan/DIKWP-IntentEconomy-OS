# Open Source Launch Plan

1. Create GitHub repository `dikwp-intenteconomy-os`.
2. Publish README, NOTICE, CITATION.cff and demo outputs.
3. Add a clear boundary: consent-first, no covert manipulation.
4. Publish a launch article in Chinese and English.
5. Invite privacy, AI governance, marketing ethics and agent security communities.
6. Prepare a public registry form for projects that want DIKWP Intent Passport review.
7. Offer paid workshops: "From Attention Economy to Intent Sovereignty".
