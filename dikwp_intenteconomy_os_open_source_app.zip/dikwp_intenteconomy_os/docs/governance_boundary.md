# Governance Boundary

This system is for explicit intent declaration, consented matching and offer auditing.

It must not be used for:

- covert profiling;
- hidden tracking;
- dark pattern generation;
- manipulative personalization;
- political microtargeting;
- credential collection;
- sensitive data extraction;
- selling inferred intent without consent;
- bypassing privacy law or platform rules;
- presenting heuristic scoring as legal or compliance certification.

High-impact intents such as healthcare, finance, legal, employment, housing, education or public services require human review and domain-specific compliance controls.
